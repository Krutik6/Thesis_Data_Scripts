setwd("/home/b7053098/Documents/HD/Data/Early_detection/Data")
df <- read.csv("mRNA_counts.csv", row.names = 1)

Gene <- df[rownames(df) %in% c("Bdnf"), ]
Gene <- df[rownames(df) %in% c("Gfap"), ]
Gene <- df[rownames(df) %in% c("Optn"), ]
Gene <- df[rownames(df) %in% c("Pitx1"), ]


cn <- colnames(Gene)
l <- 168/8

empty <- list()
for (i in seq_len(l)) {
    a <- i 
    a2 <- (i-1) * 8 +1
    b <- (i * 7) + i
    
    if (a == 1) {
        ave_df <- ave(Gene[,a]:Gene[,b])
    }else if (a != 1) {
        ave_df <- ave(Gene[,a2]:Gene[,b])
    }
    
    x <- ave_df[1]
    name <- sub(colnames(BDNF)[a2], pattern = "male_", replacement = "")
    name <- sub(name, pattern = "fe", replacement = "")
    name <- sub(name, pattern = "_1R", replacement = "")
    names(x) <- name
    empty[[i]] <- x
}


DF <- as.data.frame(unlist(empty))


emptytest <- list()
for (i in seq_len(l)) {
    a <- i 
    a2 <- (i-1) * 8 + 1
    b <- (i * 7) + i
    if (a == 1) {
        x <- as.character(paste(a, b))
    }else if (a != 1) {
        x <- as.character(paste(a2, b))
    }
    emptytest[[i]] <- x
}

s<- 1:8
for (i in seq_along(s)) {
    print(i)
}


import os
import site
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import seaborn as sns
print(sklearn.__version__)

# Add path to sources root to Python's PATH variable
site.addsitedir(os.path.dirname(os.path.dirname(os.path.abspath(''))))
from ML import *

if Import:
    Data = pd.read_csv(Data)
    Data = Data.drop(Data.columns[[0]], axis=1)
    print(Data.shape)

if ImportVal:
    Val = pd.read_csv(ValData)
    Val = Val.drop(Val.columns[[0]], axis=1)
    print(Val.shape)

if split:
    #training data
    array = Data.values
    X = array[:,0:30]
    # print(X[:1,:4])
    y = array[:,31]
    # print(y[:25])
    #val
    array2 = Val.values
    X_val = array2[:, 0:30]
    # print(X_val[:1, :4])
    y_val = array2[:, 31]
    # print(y_val[:25])

if Kfold:
    from sklearn.model_selection import StratifiedKFold
    from imblearn.over_sampling import RandomOverSampler
    from sklearn.metrics import f1_score
    from sklearn.linear_model import LogisticRegression

    cv = StratifiedKFold(n_splits=5, random_state=42, shuffle=True)

    array = Data.values
    array2 = Val.values

    accuracies = []
    for train_idx, test_idx, in cv.split(X, y):
        X_train = array[:, 0:30]
        y_train = array[:, 31]
        X_test = X_val = array2[:, 0:30]
        y_test = y_val = array2[:, 31]

        ROS = RandomOverSampler(random_state=1)
        X_train_oversampled, y_train_oversampled = ROS.fit_resample(X_train, y_train)
        X_test_oversampled, y_test_oversampled = ROS.fit_resample(X_test, y_test)

        scaler = min_max_scaler = preprocessing.MinMaxScaler().fit(X_train_oversampled)
        X_train_scaled = scaler.transform(X_train_oversampled)
        X_test_scaled = scaler.transform(X_test_oversampled)

        model = LogisticRegression(solver='liblinear', multi_class='ovr')
        model.fit(X_train_scaled, y_train_oversampled)

        y_pred = model.predict(X_train_scaled)
        print(f'For fold {cv}:')
        print(f'Accuracy: {model.score(X_test_scaled, y_test_oversampled)}')


if SKFold:
    import numpy as np
    import pandas as pd
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
    from sklearn.preprocessing import MinMaxScaler
    from imblearn.over_sampling import SMOTE
    from imblearn.pipeline import Pipeline as imbpipeline
    from sklearn.pipeline import Pipeline

    smote = SMOTE(random_state=11)
    X_train, y_train = smote.fit_resample(X, y)

    pipeline = imbpipeline(steps=[['smote', SMOTE(random_state=11)],
                                  ['scaler', MinMaxScaler()],
                                  ['classifier', LogisticRegression(random_state=11,
                                                                    max_iter=1000,
                                                                    solver='liblinear',
                                                                    multi_class='ovr')]])

    stratified_kfold = StratifiedKFold(n_splits=10,
                                       shuffle=True,
                                       random_state=11)

    param_grid = {'classifier__C': [0.001, 0.01, 0.1, 1, 10, 100, 1000]}
    grid_search = GridSearchCV(estimator=pipeline,
                               param_grid=param_grid,
                               scoring='roc_auc',
                               cv=stratified_kfold,
                               n_jobs=10)

    grid_search.fit(X, y)
    cv_score = grid_search.best_score_
    test_score = grid_search.score(X_val, y_val)
    print(f'Cross-validation score: {cv_score}\nTest score: {test_score}')

    from sklearn.metrics import plot_confusion_matrix

    print(metrics.confusion_matrix(y_val, predictedVal))
    plot_confusion_matrix(model, X_val_res, y_val_res)
    plt.savefig(os.path.join(PLOT_DIR, 'ConfuMat.png'))
    print(metrics.classification_report(y_val_res, predictedVal))

if CheckSamples:
    from pylab import rcParams
    rcParams['figure.figsize'] = 14, 8
    RANDOM_SEED = 42
    LABELS =["HD", "WT"]
    count_classes = pd.value_counts(Data['Samples'], sort=True)
    # count_classes = pd.value_counts(Val['Samples'], sort=True)
    count_classes.plot(kind = 'bar', rot=0)
    plt.title("HD or WT Class Distribution")
    plt.xticks(range(2), LABELS)
    plt.ylabel("Class")
    plt.ylabel("Frequency")
    plt.savefig(os.path.join(PLOT_DIR, 'Class_Dist.png'))

    HD = Data[Data['Samples'] == "HD"]
    WT = Data[Data['Samples'] == "WT"]
    print(HD.shape, WT.shape)

if SMOTE:
    from imblearn.over_sampling import RandomOverSampler
    ROS = RandomOverSampler(random_state=42)
    X_res, y_res = ROS.fit_resample(X, y)
    # print(X_scaled.shape, y.shape)
    # print(X_res.shape, y_res.shape)

    from collections import Counter
    # print('Original dataset shape {}'.format(Counter(y)))
    # print('Resamples dataset shape {}'.format(Counter(y_res)))

    X_val_res, y_val_res = ROS.fit_resample(X_val, y_val)
    # print(X_val_res.shape, y_val_res.shape)
    # print('Original val shape {}'.format(Counter(y_val)))
    # print('Resamples val shape {}'.format(Counter(y_val_res)))

if scaler:
    from sklearn import preprocessing
    from sklearn.preprocessing import MinMaxScaler
    scaler = min_max_scaler = preprocessing.MinMaxScaler().fit(X_res)
    X_scaled = scaler.transform(X_res)
    X_val_scaled = scaler.transform(X_val_res)
    # print(X_scaled)
    # print(X_val_scaled)



if PCA:
    from sklearn.decomposition import PCA
    pca = PCA(n_components=30)
    pca.fit(X_scaled)
    X_pca=pca.transform(X_scaled)
    print(X_scaled.shape)
    print(X_pca.shape)
    X_val_pca = pca.transform(X_val_scaled)
    print(X_val_pca.shape)
    X_scaled = X_pca
    X_val_scaled = X_val_pca

if crossVal:
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import ShuffleSplit
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import cross_val_predict
    from sklearn import metrics

    model = LogisticRegression(solver='liblinear', multi_class='ovr').fit(X_scaled, y_res)
    cv = ShuffleSplit(n_splits=50, test_size=0.2, random_state=1)
    scores = cross_val_score(model, X_scaled, y_res, cv=cv)
    print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
    predictedVal = cross_val_predict(model, X_val_scaled, y_val_res, cv=15)
    print(predictedVal.shape)
    metVal = metrics.accuracy_score(y_val_res, predictedVal)
    print(metVal)

if confusionMatrix:
    from sklearn.metrics import plot_confusion_matrix
    print(metrics.confusion_matrix(y_val_res, predictedVal))
    plot_confusion_matrix(model, X_val_res, y_val_res)
    plt.savefig(os.path.join(PLOT_DIR, 'ConfuMat.png'))
    print(metrics.classification_report(y_val_res, predictedVal))

if FE_test:
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score, f1_score
    from sklearn.metrics import f1_score, confusion_matrix
    from sklearn.model_selection import ShuffleSplit
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import cross_val_predict
    from sklearn import metrics
    from sklearn.feature_selection import RFE
    from sklearn.feature_selection import RFECV
    from sklearn.feature_selection import SelectKBest, chi2

    Data.Samples.replace(('HD', 'WT'), (1, 0), inplace=True)

    categorical_feature_columns = list(set(Data.columns) - set(Data._get_numeric_data().columns))
    print(categorical_feature_columns)
    numerical_feature_columns = list(Data._get_numeric_data().columns)
    print(numerical_feature_columns)
    target = 'Samples'

    k = 30  # number of variables for heatmap
    cols = Data[numerical_feature_columns].corr().nlargest(k, target)[target].index
    cm = Data[cols].corr()
    cm1 = cm.round(1)
    plt.figure(figsize=(16, 13))
    sns.heatmap(cm1, annot=True, cmap='viridis')
    plt.savefig(os.path.join(PLOT_DIR, 'hmap_WT_samples.png'))

    model = LogisticRegression(solver='liblinear', multi_class='ovr').fit(X_res, y_res)
    cv = ShuffleSplit(n_splits=50, test_size=0.2, random_state=1)
    scores = cross_val_score(model, X_res, y_res, cv=cv)
    print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
    predictedVal = cross_val_predict(model, X_val_res, y_val_res, cv=15)
    metVal = metrics.accuracy_score(y_val_res, predictedVal)
    print(metVal)

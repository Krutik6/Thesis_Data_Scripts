# Find male DE genes
setwd("~/Documents/HD/Data/mRNA/DE/WT/Male")

Files <- list.files(getwd())

EmptyList <- list()

for (i in seq_along(Files)){
    EmptyList[[i]] <- read.csv(Files[i], sep = ',')
    names(EmptyList)[[i]] <- Files[i]
}

M_SigList <- lapply(EmptyList, function(x) {x[which(x$padj <0.05),]})

# Females
setwd("~/Documents/HD/Data/mRNA/DE/WT/Female/")

Files <- list.files(getwd())
EmptyList <- list()

for (i in seq_along(Files)){
    EmptyList[[i]] <- read.csv(Files[i], sep = ',')
    names(EmptyList)[[i]] <- Files[i]
}

F_SigList <- lapply(EmptyList, function(x) {x[which(x$padj <0.05),]})


library(dplyr)
M_Sig_genes <- bind_rows(M_SigList, .id = "M") %>% 
             group_by(X) %>% 
             summarize(occurance = n()) %>% 
             filter(occurance > 6)
F_Sig_genes <- bind_rows(F_SigList, .id = "F") %>% 
             group_by(X) %>% 
             summarize(occurance = n()) %>% 
             filter(occurance > 6)


intersect(M_Sig_genes$X, F_Sig_genes$X)

F_tran <- as.data.frame(F_tran)
F_tran$Samples <- rownames(F_tran)
F_tran$Samples <- sub(F_tran$Samples, pattern = "...$", replacement = "")

M_tran <- as.data.frame(M_tran)
M_tran$Samples <- rownames(M_tran)
M_tran$Samples <- sub(M_tran$Samples, pattern = "...$", replacement = "")

setwd("~/Documents/HD/Data/MostDE/DE_interest/DE_consistently_found")
write.csv(M_Sig_genes, "M_sig_mRNA.csv")
write.csv(F_Sig_genes, "F_sig_mRNA.csv")

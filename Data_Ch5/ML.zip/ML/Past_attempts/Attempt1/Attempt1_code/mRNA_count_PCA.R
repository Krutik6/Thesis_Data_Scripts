# Now to investigate count data after it has been normalised by DESeq2
setwd("~/Documents/HD/Data/MostDE/DE_interest")
mRNA <- read.table("Normalised_counts/normalized_mRNA.txt")
mRNA <- mRNA[,-c(144:167)]
Groups <- sub(colnames(mRNA), pattern = '...$', replacement = "")
#Males - normalised counts
library(dplyr)
M_only <- mRNA %>% 
         select(starts_with("male"))
M_mRNA <- read.csv('DE_consistently_found/M_sig_mRNA.csv', row.names = 1)
M_mRNA_consistent <- M_only[which(rownames(M_only) %in% M_mRNA$X),] 
#Females - normalised counts
F_only <- mRNA %>% 
    select(starts_with("female"))
F_mRNA <- read.csv('DE_consistently_found/F_sig_mRNA.csv', row.names = 1)
F_mRNA_consistent <- F_only[which(rownames(F_only) %in% F_mRNA$X),] 
#test PCA on male
library(factoextra)
M_tran <- t(M_mRNA_consistent)
res.pca <- prcomp(M_tran, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)
#test PCA on female
F_tran <- t(F_mRNA_consistent)
res.pca <- prcomp(F_tran, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)

F_tran <- as.data.frame(F_tran)
F_tran$Samples <- sub(rownames(F_tran), pattern = "...$", replacement = "")

M_tran <- as.data.frame(M_tran)
M_tran$Samples <- sub(rownames(M_tran), pattern = "...$", replacement = "")

setwd("Input_ML/")
write.csv(F_tran, "F_mRNA.csv")
write.csv(M_tran, "M_mRNA.csv")

# Now to investigate count data after it has been normalised by DESeq2
setwd("~/Documents/HD/Data/MostDE/DE_interest")
miRNA <- read.table("Normalised_counts/normalized_miRNA.txt")
miRNA <- miRNA[,-c(144:166)]
Groups <- sub(colnames(miRNA), pattern = '...$', replacement = "")
#Males - normalised counts
library(dplyr)
M_only <- miRNA %>% 
        select(starts_with("male"))
M_miRNA <- read.csv('DE_consistently_found/M_sig_miRNA.csv', row.names = 1)
M_miRNA_consistent <- M_only[which(rownames(M_only) %in% M_miRNA$X),] 
#Females - normalised counts
F_only <- miRNA %>% 
    select(starts_with("female"))
F_miRNA <- read.csv('DE_consistently_found/F_sig_miRNA.csv', row.names = 1)
F_miRNA_consistent <- F_only[which(rownames(F_only) %in% F_miRNA$X),] 
#test PCA on male
library(factoextra)
M_tran <- t(M_miRNA_consistent)
res.pca <- prcomp(M_tran, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)
#test PCA on female
F_tran <- t(F_miRNA_consistent)
res.pca <- prcomp(F_tran, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)


F_tran <- as.data.frame(F_tran)
F_tran$Samples <- sub(rownames(F_tran), pattern = "...$", replacement = "")

M_tran <- as.data.frame(M_tran)
M_tran$Samples <- sub(rownames(M_tran), pattern = "...$", replacement = "")

setwd("Input_ML/")
write.csv(F_tran, "F_miRNA.csv")
write.csv(M_tran, "M_miRNA.csv")

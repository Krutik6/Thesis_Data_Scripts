# Find male DE genes
setwd("~/Documents/HD/Data/miRNA/DE/NoBatch/WT/Male/")

Files <- list.files(getwd())

EmptyList <- list()

for (i in seq_along(Files)){
    EmptyList[[i]] <- read.csv(Files[i], sep = ',')
    names(EmptyList)[[i]] <- Files[i]
}

M_SigList <- lapply(EmptyList, function(x) {x[which(x$padj <0.2),]})

# Females
setwd("~/Documents/HD/Data/miRNA/DE/NoBatch/WT/Female/")

Files <- list.files(getwd())
EmptyList <- list()

for (i in seq_along(Files)){
    EmptyList[[i]] <- read.csv(Files[i], sep = ',')
    names(EmptyList)[[i]] <- Files[i]
}

F_SigList <- lapply(EmptyList, function(x) {x[which(x$padj <0.2),]})


library(dplyr)
M_Sig_genes <- bind_rows(M_SigList, .id = "M") %>% 
    group_by(X) %>% 
    summarize(occurance = n()) %>% 
    filter(occurance > 6)
F_Sig_genes <- bind_rows(F_SigList, .id = "F") %>% 
    group_by(X) %>% 
    summarize(occurance = n()) %>% 
    filter(occurance > 6)


intersect(M_Sig_genes$X, F_Sig_genes$X)

setwd("~/Documents/HD/Data/MostDE/DE_interest/DE_consistently_found")
write.csv(M_Sig_genes, "M_sig_miRNA.csv")
write.csv(F_Sig_genes, "F_sig_miRNA.csv")

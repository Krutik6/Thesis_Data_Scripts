library(factoextra)
setwd("~/Documents/HD/Data/DE_genders_merged/ML_input")

miRNA <- read.csv("miRNA_data.csv", row.names = 1)
mRNA <- read.csv("mRNA_data.csv", row.names = 1)

mRNA <- mRNA[which(rownames(mRNA) %in% rownames(miRNA)),]
miRNA <- miRNA[which(rownames(miRNA) %in% rownames(mRNA)),]
mRNA$Samples <- NULL

intersect(rownames(mRNA), rownames(miRNA))
Data <- cbind(mRNA, miRNA)
Samples <- Data$Samples
Data$Samples <- NULL

res.pca <- prcomp(Data, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)
#
Data$Samples <- Samples
write.csv(Data, "ML_Data.csv", row.names = TRUE)

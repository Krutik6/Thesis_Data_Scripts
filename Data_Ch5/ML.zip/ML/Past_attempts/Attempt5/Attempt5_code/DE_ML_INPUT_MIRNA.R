library(DESeq2)
library(limma)
library(dplyr)
library(tidyverse) 
library(factoextra)
setwd("~/Documents/HD/Data/DE_genders_merged/Data")
miRNA <- read.csv("miRNA_counts.csv", row.names = 1)
colnames(miRNA)
miRNA <- miRNA[,-c(93, 127)]
colnames(miRNA)
miRNA<- miRNA %>% select(-contains("6m"))

colnames(miRNA)
Pheno <- read.csv("miRNA_Pheno.csv", row.names = 1)
Pheno <- Pheno[-c(93, 127),]
Pheno <- Pheno %>% 
    filter(!grepl('6m', AGE))

gless <- sub(Pheno$Name, pattern = "fe", replacement = "")
gless <- sub(gless, pattern = "male_", replacement = "")
Pheno$Genderless <- gless

m <- mapply(miRNA, FUN=as.integer)
rownames(m) <- rownames(miRNA)

Samples <- colnames(m)
Conditions <- Pheno$Genderless
colData <- cbind(Samples, Conditions)
rownames(colData) <- colnames(m)

dds <- DESeqDataSetFromMatrix(countData = m, colData = colData, 
                              design = ~Conditions)

keep <- rowSums(counts(dds)) >= 10
dds <- dds[keep,]

plotMDS(dds@assays@data@listData$counts, col = as.numeric(dds$Conditions))
boxplot(dds@assays@data@listData$counts, col = as.numeric(dds$Conditions))

### normalised counts for ML
dds <- estimateSizeFactors(dds)
sizeFactors(dds)
normalized_counts <- counts(dds, normalized=TRUE)
write.table(normalized_counts, file="normalized_miRNA_counts.txt", sep="\t",
            quote=F, col.names=NA)

###
dds$Conditions <- factor(dds$Conditions, levels = unique(dds$Conditions))
dds$Conditions
dds <- DESeq(dds)
resultsNames(dds)

getDE <- function(numC, denC){
    res <- results(dds, contrast= c("Conditions", numC, denC))
    res_B <- suppressMessages(as.data.frame(lfcShrink(dds=dds, 
                                                      contrast=c("Conditions",
                                                                 numC,
                                                                 denC), 
                                                      res=res,
                                                      type = 'ashr')))
    return(res_B)
}

Q20_WT_2m <- getDE(numC = 'Q20_2m', denC = 'WT_2m')
Q20_WT_10m <- getDE(numC = 'Q20_10m', denC = 'WT_10m')

Q80_WT_2m <- getDE(numC = 'Q80_2m', denC = 'WT_2m')
Q80_WT_10m <- getDE(numC = 'Q80_10m', denC = 'WT_10m')

Q92_WT_2m <- getDE(numC = 'Q92_2m', denC = 'WT_2m')
Q92_WT_10m <- getDE(numC = 'Q92_10m', denC = 'WT_10m')

Q111_WT_2m <- getDE(numC = 'Q111_2m', denC = 'WT_2m')
Q111_WT_10m <- getDE(numC = 'Q111_10m', denC = 'WT_10m')

Q140_WT_2m <- getDE(numC = 'Q140_2m', denC = 'WT_2m')
Q140_WT_10m <- getDE(numC = 'Q140_10m', denC = 'WT_10m')

Q175_WT_2m <- getDE(numC = 'Q175_2m', denC = 'WT_2m')
Q175_WT_10m <- getDE(numC = 'Q175_10m', denC = 'WT_10m')

################################################################################
EmptyList <- list()
EmptyList[["Q20_WT_2m"]] <- Q20_WT_2m
EmptyList[["Q20_WT_10m"]] <- Q20_WT_10m
EmptyList[["Q80_WT_2m"]] <- Q80_WT_2m
EmptyList[["Q80_WT_10m"]] <- Q80_WT_10m
EmptyList[["Q92_WT_2m"]] <- Q92_WT_2m
EmptyList[["Q92_WT_10m"]] <- Q92_WT_10m
EmptyList[["Q111_WT_2m"]] <- Q111_WT_2m
EmptyList[["Q111_WT_10m"]] <- Q111_WT_10m
EmptyList[["Q140_WT_2m"]] <- Q140_WT_2m
EmptyList[["Q140_WT_10m"]] <- Q140_WT_10m
EmptyList[["Q175_WT_2m"]] <- Q175_WT_2m
EmptyList[["Q175_WT_10m"]] <- Q175_WT_10m

SigList <- lapply(EmptyList, function(x) {x[which(x$pvalue <0.05),]})

NamedList <- lapply(SigList, function(x) {cbind(x, rownames(x))})

cNames <- colnames(NamedList[[1]])
cNames[6] <- "Names"

NamesinList <- lapply(NamedList, setNames, cNames)
colnames(NamesinList[[1]])

Sig_genes <- bind_rows(NamesinList) %>% 
    group_by(Names) %>% 
    summarize(occurance = n()) %>% 
    filter(occurance > 4)
################################################################################

norm_miRNA <- read.table("normalized_miRNA_counts.txt", row.names = 1)
colnames(norm_miRNA) <- colnames(miRNA)
miRNA_consistent <- miRNA[which(rownames(miRNA) %in% Sig_genes$Names),] 

#PCA plots
Data <- t(miRNA_consistent)
res.pca <- prcomp(Data, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)

DF <- as.data.frame(Data)
DF$Samples <- gless
setwd("~/Documents/HD/Data/DE_genders_merged/ML_input")
write.csv(DF, "miRNA_data.csv")

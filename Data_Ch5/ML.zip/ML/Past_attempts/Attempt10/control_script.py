import os
import site
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy import mean
from numpy import std
from sklearn.datasets import make_classification
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.feature_selection import RFE
from sklearn.tree import DecisionTreeClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import cross_val_predict
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.feature_selection import GenericUnivariateSelect
from sklearn.feature_selection import f_classif
from sklearn.feature_selection import mutual_info_classif
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn import metrics
import sklearn
print(sklearn.__version__)

# Add path to sources root to Python's PATH variable
site.addsitedir(os.path.dirname(os.path.dirname(os.path.abspath(''))))
from ML import *

# import M_mRNA csv
if Import:
    Data = pd.read_csv(Data)
    Data = Data.drop(Data.columns[[0]], axis=1)
    print(Data.shape)

if DataInvestigation:
    print(print(Data.head(20)))
    print(Data.describe())
    print(Data.iloc[:,-1:].head(20))

if makePlotDF:
    plotDF = Data.iloc[:,:-1]
    print(plotDF.shape)

if boxplot:
    plotDF.plot(kind='box', subplots=True, showfliers=False, sharex=False, sharey=False)
    plt.savefig(os.path.join(PLOT_DIR, 'boxplot.png'))
    plt.close()

if hist:
    plotDF.hist()
    plt.savefig(os.path.join(PLOT_DIR, 'hist.png'))
    plt.close()

if scatter:
    scatter_matrix(plotDF)
    plt.savefig(os.path.join(PLOT_DIR, 'scatter.png'))
    plt.close()

if split:
    array = Data.values
    X = array[:,0:57]
    print(X)
    y = array[:,58]
    print(y)


if RecursiveSelection:
    # create pipeline
    rfe = RFE(estimator=DecisionTreeClassifier(), n_features_to_select=58)
    model = DecisionTreeClassifier()
    pipeline = Pipeline(steps=[('s', rfe), ('m', model)])
    # evaluate model
    cv = RepeatedStratifiedKFold(n_splits=7, n_repeats=3, random_state=1)
    n_scores = cross_val_score(pipeline, X, y, scoring='accuracy', cv=cv, n_jobs=-1, error_score='raise')
    # report performance
    print('Accuracy: %.3f (%.3f)' % (mean(n_scores), std(n_scores)))
    # summarize all features
    rfe.fit(X, y)
    for i in range(X.shape[1]):
        print('Column: %d, Selected %s, Rank: %.3f' % (i, rfe.support_[i], rfe.ranking_[i]))

if establishTestSize:
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10,
                                                                    random_state=1)

if featureSelection:
    selector = SelectKBest(chi2, k=25)
    X_train_selected = selector.fit_transform(X_train, y_train)
    print(X_train_selected.shape)
    X_validation_selected = selector.transform(X_validation)
    print(X_validation_selected.shape)

if printSelected:
    mask = selector.get_support()
    print(selector.get_support())
    feature_names = list(Data.iloc[:,:-1].columns.values)
    print(feature_names)
    new_features = []
    for bool, feature in zip(mask, feature_names):
        if bool:
            new_features.append(feature)

    dataframe = pd.DataFrame(X_train_selected, columns=new_features)
    print(dataframe.head(n=5))
    print(dataframe.shape)


if Alg_tests:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=5, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train_selected, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))

if plotAlg:
    # Compare Algorithms
    plt.boxplot(results, labels=names)
    plt.title('Algorithm Comparison')
    plt.savefig(os.path.join(PLOT_DIR, 'M_mRNA_algs.png'))
    plt.close()

if crossVal:
    model = DecisionTreeClassifier().fit(X, y)
    cv = ShuffleSplit(n_splits=5, test_size=0.1, random_state=1)
    scores = cross_val_score(model, X, y, cv=cv)
    print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
    predicted = cross_val_predict(model, X, y, cv=5)
    print(predicted.shape)
    met = metrics.accuracy_score(y, predicted)
    print(met)


if trainModel:
    model = DecisionTreeClassifier()
    model.fit(X_train, y_train)
    predictions = model.predict(X_validation)
    print(accuracy_score(y_validation, predictions))
    #print(confusion_matrix(y_validation, predictions))
    #print(classification_report(y_validation, predictions))

if train100:
    EmptyList = []

    for i in range(1000):
        model = DecisionTreeClassifier()
        model.fit(X_train_selected, y_train)
        predictions = model.predict(X_validation_selected)
        Acc = accuracy_score(y_validation, predictions)
        EmptyList.append(Acc)

if AverageModel:
    def Average(lst):
        return sum(lst) / len(lst)
    average = Average(EmptyList)
    print("Average of the ML predictions are =", round(average, 2))
    print("The minimum prediction is =" , min(EmptyList))
    print("The maximum predication is =", max(EmptyList))




import os
import site
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import seaborn as sns
print(sklearn.__version__)

# Add path to sources root to Python's PATH variable
site.addsitedir(os.path.dirname(os.path.dirname(os.path.abspath(''))))
from ML import *

if Import:
    Data = pd.read_csv(Data)
    Data = Data.drop(Data.columns[[0]], axis=1)
    print(Data.shape)

if ImportVal:
    Val = pd.read_csv(ValData)
    Val = Val.drop(Val.columns[[0]], axis=1)
    print(Val.shape)

if undersample_test:
    from sklearn.metrics import classification_report, accuracy_score
    from sklearn.ensemble import IsolationForest
    from sklearn.neighbors import LocalOutlierFactor
    from sklearn.svm import OneClassSVM
    from pylab import rcParams

    rcParams['figure.figsize'] = 14, 8
    RANDOM_SEED = 42
    LABELS =["HD", "WT"]

    count_classes = pd.value_counts(Data['Samples'], sort=True)
    count_classes.plot(kind = 'bar', rot=0)
    plt.title("HD or WT Class Distribution")
    plt.xticks(range(2), LABELS)
    plt.ylabel("Class")
    plt.ylabel("Frequency")
    plt.savefig(os.path.join(PLOT_DIR, 'Class_Dist.png'))

    HD = Data[Data['Samples'] == "HD"]
    WT = Data[Data['Samples'] == "WT"]
    print(HD.shape, WT.shape)

    array = Data.values
    X = array[:, 0:30]
    y = array[:, 31]

    from imblearn.under_sampling import NearMiss
    nm = NearMiss(sampling_strategy='auto', version=1,
    n_neighbors=3, n_neighbors_ver3=3, n_jobs=None)
    X_res, y_res = nm.fit_resample(X, y)
    print(X_res.shape, y_res.shape)

    from collections import Counter
    print('Origional dataset shape {}'.format(Counter(y)))
    print('Resamples dataset shape {}'.format(Counter(y_res)))

    array2 = Val.values
    X_val = array2[:, 0:30]
    y_val = array2[:, 31]
    X_val_res, y_val_res = nm.fit_resample(X_val, y_val)
    print(X_val_res.shape, y_val_res.shape)
    from collections import Counter
    print('Origional dataset shape {}'.format(Counter(y_val)))
    print('Resamples dataset shape {}'.format(Counter(y_val_res)))

    from sklearn import preprocessing
    from sklearn.preprocessing import MinMaxScaler
    scaler = min_max_scaler = preprocessing.MinMaxScaler().fit(X_res)
    X_scaled = scaler.transform(X_res)
    X_val_scaled = scaler.transform(X_val_res)

    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import ShuffleSplit
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import cross_val_predict
    from sklearn import metrics
    model = LogisticRegression(solver='liblinear', multi_class='ovr').fit(X_scaled, y_res)
    cv = ShuffleSplit(n_splits=50, test_size=0.2, random_state=1)
    scores = cross_val_score(model, X_scaled, y_res, cv=cv)
    print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
    predictedVal = cross_val_predict(model, X_val_scaled, y_val_res, cv=15)
    print(predictedVal.shape)
    metVal = metrics.accuracy_score(y_val_res, predictedVal)
    print(metVal)





if split:
    #training data
    array = Data.values
    X = array[:,0:30]
    # print(X[:1,:4])
    y = array[:,31]
    # print(y[:25])
    #val
    array2 = Val.values
    X_val = array2[:, 0:30]
    # print(X_val[:1, :4])
    y_val = array2[:, 31]
    # print(y_val[:25])


if scaler:
    from sklearn import preprocessing
    from sklearn.preprocessing import MinMaxScaler
    scaler = min_max_scaler = preprocessing.MinMaxScaler().fit(X)
    X_scaled = scaler.transform(X)
    X_val_scaled = scaler.transform(X_val)
    print(X_scaled)
    print(X_val_scaled)

if crossVal:
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import ShuffleSplit
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import cross_val_predict
    from sklearn import metrics

    model = LogisticRegression(solver='liblinear', multi_class='ovr').fit(X_scaled, y)
    cv = ShuffleSplit(n_splits=50, test_size=0.2, random_state=1)
    scores = cross_val_score(model, X_scaled, y, cv=cv)
    print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
    predictedVal = cross_val_predict(model, X_val_scaled, y_val, cv=15)
    print(predictedVal.shape)
    metVal = metrics.accuracy_score(y_val, predictedVal)
    print(metVal)

if confusionMatrix:
    from sklearn.metrics import plot_confusion_matrix

    print(metrics.confusion_matrix(y_val, predictedVal))
    plot_confusion_matrix(model, X_val_scaled, y_val)
    plt.savefig(os.path.join(PLOT_DIR, 'ConfuMat.png'))
    print(metrics.classification_report(y_val, predictedVal))



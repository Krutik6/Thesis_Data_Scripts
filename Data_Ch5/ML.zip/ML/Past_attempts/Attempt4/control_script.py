import os
import site
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import matplotlib
from pandas.plotting import scatter_matrix
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

# Add path to sources root to Python's PATH variable
site.addsitedir(os.path.dirname(os.path.dirname(os.path.abspath(''))))
from ML import *

# import M_mRNA csv
if Import_M_mRNA:
    M_mRNA = pd.read_csv(M_mRNA)
    M_mRNA = M_mRNA.drop(M_mRNA.columns[[0]], axis=1)
    print(M_mRNA.shape)

if DataInvestigation:
    print(print(M_mRNA.head(20)))
    print(M_mRNA.shape)
    print(M_mRNA.describe())
    print(M_mRNA.iloc[:,-1:].head(20))

if makePlotDF:
    plotDF = M_mRNA.iloc[:,:-1]
    print(plotDF.shape)

if boxplot:
    plotDF.plot(kind='box', subplots=True, showfliers=False, sharex=False, sharey=False)
    plt.savefig(os.path.join(PLOT_DIR, 'boxplot.png'))
    plt.close()

if hist:
    plotDF.hist()
    plt.savefig(os.path.join(PLOT_DIR, 'hist.png'))
    plt.close()

if scatter:
    scatter_matrix(plotDF)
    plt.savefig(os.path.join(PLOT_DIR, 'scatter.png'))
    plt.close()

if split_M_mRNA:
    array = M_mRNA.values
    X = array[:,0:49]
    print(X)
    y = array[:,50]
    print(y)
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10, random_state=1)

if Alg_tests_M_mRNA:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=2, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))

if plotAlg_M_mRNA:
    # Compare Algorithms
    plt.boxplot(results, labels=names)
    plt.title('Algorithm Comparison')
    plt.savefig(os.path.join(PLOT_DIR, 'M_mRNA_algs.png'))
    plt.close()

# import F_mRNA csv
if Import_F_mRNA:
    F_mRNA = pd.read_csv(F_mRNA)
    F_mRNA = F_mRNA.drop(F_mRNA.columns[[0]], axis=1)
    print(F_mRNA.shape)

if split_F_mRNA:
    array = F_mRNA.values
    X = array[:,0:81]
    print(X)
    y = array[:,82]
    print(y)
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10, random_state=1)

if Alg_tests_F_mRNA:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=2, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))


# import M_miRNA csv
if Import_M_miRNA:
    M_miRNA = pd.read_csv(M_miRNA)
    M_miRNA = M_miRNA.drop(M_miRNA.columns[[0]], axis=1)
    print(M_miRNA.shape)

if split_M_miRNA:
    array = M_miRNA.values
    X = array[:,0:13]
    print(X)
    y = array[:,14]
    print(y)
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10, random_state=1)

if Alg_tests_M_miRNA:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=2, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))

# import F_miRNA csv
if Import_F_miRNA:
    F_miRNA = pd.read_csv(F_miRNA)
    F_miRNA = F_miRNA.drop(F_miRNA.columns[[0]], axis=1)
    print(F_miRNA.shape)

if split_F_miRNA:
    array = F_miRNA.values
    X = array[:,0:6]
    print(X)
    y = array[:,7]
    print(y)
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10, random_state=1)

if Alg_tests_F_miRNA:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=2, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))

# Joined mRNA-miRNA

# import M_data csv
if Import_M_data:
    M_data = pd.read_csv(M_data)
    M_data = M_data.drop(M_data.columns[[0]], axis=1)
    print(M_data.shape)

if split_M_data:
    array = M_data.values
    X = array[:,0:51]
    print(X)
    y = array[:,52]
    print(y)
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10, random_state=1)

if Alg_tests_M_data:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=2, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))

# import F_data csv
if Import_F_data:
    F_data = pd.read_csv(F_data)
    F_data = F_data.drop(F_data.columns[[0]], axis=1)
    print(F_data.shape)

if split_F_data:
    array = F_data.values
    X = array[:,0:69]
    print(X)
    y = array[:,70]
    print(y)
    X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.10, random_state=1)

if Alg_tests_F_data:
    models = []
    models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
    models.append(('LDA', LinearDiscriminantAnalysis()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('CART', DecisionTreeClassifier()))
    models.append(('NB', GaussianNB()))
    models.append(('SVM', SVC(gamma='auto')))
    # evaluate each model in turn
    results = []
    names = []
    for name, model in models:
        kfold = StratifiedKFold(n_splits=2, random_state=1, shuffle=True)
        cv_results = cross_val_score(model, X_train, y_train, cv=kfold, scoring='accuracy')
        results.append(cv_results)
        names.append(name)
        print('%s: %f (%f)' % (name, cv_results.mean(), cv_results.std()))
import os
import site
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import seaborn as sns
print(sklearn.__version__)

# Add path to sources root to Python's PATH variable
site.addsitedir(os.path.dirname(os.path.dirname(os.path.abspath(''))))
from ML import *

if Import:
    Data = pd.read_csv(Data)
    Data = Data.drop(Data.columns[[0]], axis=1)
    print(Data.shape)

if ImportVal:
    Val = pd.read_csv(ValData)
    Val = Val.drop(Val.columns[[0]], axis=1)
    print(Val.shape)

if Hmap_train:
    Data.Samples.replace(('HD', 'WT'), (1, 0), inplace=True)

    categorical_feature_columns = list(set(Data.columns) - set(Data._get_numeric_data().columns))
    print(categorical_feature_columns)
    numerical_feature_columns = list(Data._get_numeric_data().columns)
    print(numerical_feature_columns)
    target = 'Samples'

    k = 30  # number of variables for heatmap
    cols = Data[numerical_feature_columns].corr().nlargest(k, target)[target].index
    cm = Data[cols].corr()
    cm1 = cm.round(1)
    plt.figure(figsize=(16, 13))
    sns.heatmap(cm1, annot=True, cmap='viridis')
    plt.savefig(os.path.join(PLOT_DIR, 'hmap_train.png'))

if Hmap_test:
    Val.Samples.replace(('HD', 'WT'), (1, 0), inplace=True)

    categorical_feature_columns = list(set(Val.columns) - set(Val._get_numeric_data().columns))
    print(categorical_feature_columns)
    numerical_feature_columns = list(Val._get_numeric_data().columns)
    print(numerical_feature_columns)
    target = 'Samples'

    k = 30  # number of variables for heatmap
    cols = Val[numerical_feature_columns].corr().nlargest(k, target)[target].index
    cm = Val[cols].corr()
    cm1 = cm.round(1)
    plt.figure(figsize=(16, 13))
    sns.heatmap(cm1, annot=True, cmap='viridis')
    plt.savefig(os.path.join(PLOT_DIR, 'hmap_test.png'))




if KFold:
    from sklearn.model_selection import StratifiedKFold
    from imblearn.over_sampling import RandomOverSampler
    from sklearn import preprocessing
    from sklearn.preprocessing import MinMaxScaler
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    from sklearn import metrics
    from sklearn.metrics import confusion_matrix
    from sklearn.metrics import plot_confusion_matrix
    from sklearn import datasets, metrics, model_selection, svm

    cv = StratifiedKFold(n_splits=5, random_state=42, shuffle=True)

    array = Data.values
    X_train = array[:, 0:30]
    y_train = array[:, 31]

    array2 = Val.values
    X_test = array2[:, 0:30]
    y_test = array2[:, 31]

    CM = []
    Acc = []
    ROC = []
    for train_idx, test_idx, in cv.split(X_train, y_train):

        ROS = RandomOverSampler(random_state=42)
        X_train_oversampled, y_train_oversampled = ROS.fit_resample(X_train, y_train)
        X_test_oversampled, y_test_oversampled = ROS.fit_resample(X_test, y_test)

        scaler = min_max_scaler = preprocessing.MinMaxScaler().fit(X_train_oversampled)
        X_train_scaled = scaler.transform(X_train_oversampled)
        X_test_scaled = scaler.transform(X_test_oversampled)

        model = LogisticRegression()
        model.fit(X_train_scaled, y_train_oversampled)

        y_pred = model.predict(X_train_scaled)
        Acc_score = model.score(X_test_scaled, y_test_oversampled)
        roc_score = roc_auc_score(y_test_oversampled, model.decision_function(X_test_scaled))
        confmat = metrics.confusion_matrix(y_test_oversampled, model.predict(X_test_scaled))

        Acc.append(Acc_score)
        ROC.append(roc_score)
        CM.append(confmat)


    print(f'Validation Accuracy: {Acc}')
    print(f'ROC scores: {ROC}')
    print(f'Confusion matrices: {CM}')

if ConfusionMatrix:
    # Plot normalized confusion matrix
    titles_options = [("Confusion matrix", None),
                      ("Normalised confusion matrix", 'true')]
    for title, normalize in titles_options:
        disp = plot_confusion_matrix(model, X_test_scaled, y_test_oversampled,
                                     display_labels=['HD', 'WT'],
                                     cmap=plt.cm.Blues,
                                     normalize='true')
        disp.ax_.set_title(title)

        print(title)
        print(disp.confusion_matrix)
        plt.savefig(os.path.join(PLOT_DIR, 'ConfuMat.png'))

if ROC:
    metrics.plot_roc_curve(model, X_test_scaled, y_test_oversampled)
    plt.savefig(os.path.join(PLOT_DIR, 'ROCAUC.png'))




library(DESeq2)
library(limma)
library(dplyr)
library(tidyverse) 
library(factoextra)
setwd("~/Documents/HD/Data/HDvsnoHD/Data")
mRNA <- read.csv("mRNA_counts_V2.csv", row.names = 1)
colnames(mRNA)
Pheno <- read.csv("Pheno_mRNA_V2.csv")

HD <- sub(Pheno$Name, pattern = "fe", replacement = "")
HD <- sub(HD, pattern = "male_", replacement = "")
HD <- sub(HD, pattern = "Q20", replacement = "WT")
HD <- sub(HD, pattern = "Q111", replacement = "HD")
HD <- sub(HD, pattern = "Q140", replacement = "HD")
HD <- sub(HD, pattern = "Q175", replacement = "HD")
HD <- sub(HD, pattern = "Q80", replacement = "HD")
HD <- sub(HD, pattern = "Q92", replacement = "HD")
HD

m <- mapply(mRNA, FUN=as.integer)
rownames(m) <- rownames(mRNA)

Samples <- colnames(m)
Conditions <- HD
colData <- cbind(Samples, Conditions)
rownames(colData) <- colnames(m)

dds <- DESeqDataSetFromMatrix(countData = m, colData = colData, 
                              design = ~Conditions)

keep <- rowSums(counts(dds)) >= 10
dds <- dds[keep,]

plotMDS(dds@assays@data@listData$counts, col = as.numeric(dds$Conditions))
boxplot(dds@assays@data@listData$counts, col = as.numeric(dds$Conditions))

### normalised counts for ML
dds <- estimateSizeFactors(dds)
sizeFactors(dds)
normalized_counts <- counts(dds, normalized=TRUE)
write.table(normalized_counts, file="normalized_mRNA_counts.txt", sep="\t",
            quote=F, col.names=NA)

###
dds$Conditions <- factor(dds$Conditions, levels = unique(dds$Conditions))
dds$Conditions
dds <- DESeq(dds)
resultsNames(dds)

getDE <- function(numC, denC){
    res <- results(dds, contrast= c("Conditions", numC, denC))
    res_B <- suppressMessages(as.data.frame(lfcShrink(dds=dds, 
                                                      contrast=c("Conditions",
                                                                 numC,
                                                                 denC), 
                                                      res=res,
                                                      type = 'ashr')))
    return(res_B)
}

HD_2m <- getDE(numC = 'HD_2m', denC = 'WT_2m')
HD_10m <- getDE(numC = 'HD_10m', denC = 'WT_10m')

################################################################################
EmptyList <- list()
EmptyList[["HD_2m"]] <- HD_2m
EmptyList[["HD_10m"]] <- HD_10m

SigList <- lapply(EmptyList, function(x) {x[which(x$pvalue <0.05),]})

NamedList <- lapply(SigList, function(x) {cbind(x, rownames(x))})

cNames <- colnames(NamedList[[1]])
cNames[6] <- "Names"

NamesinList <- lapply(NamedList, setNames, cNames)
colnames(NamesinList[[1]])

Sig_genes <- bind_rows(NamesinList) %>% 
    group_by(Names) %>% 
    summarize(occurance = n()) %>% 
    filter(occurance > 1)
################################################################################
norm_mRNA <- read.table("normalized_mRNA_counts.txt", row.names = 1)
colnames(norm_mRNA) <- colnames(mRNA)
mRNA_consistent <- norm_mRNA[which(rownames(norm_mRNA) %in% Sig_genes$Names),] 

#PCA plots
Data <- t(mRNA_consistent)
res.pca <- prcomp(Data, scale = TRUE)
fviz_eig(res.pca)
fviz_pca_ind(res.pca,
             col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE 
)
fviz_pca_var(res.pca,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)
fviz_pca_biplot(res.pca, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)

DF <- as.data.frame(Data)
DF$Samples <- HD
setwd("~/Documents/HD/Data/DE_genders_merged/ML_input")
write.csv(DF, "mRNA_data.csv")
